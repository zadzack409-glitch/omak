# om

Small utilities package.

Installation (local build):

```bash
python -m pip install --upgrade build
python -m build
python -m pip install dist/om-0.1.0-py3-none-any.whl
```

Run tests:

```bash
python -m pip install pytest
pytest -q
```
