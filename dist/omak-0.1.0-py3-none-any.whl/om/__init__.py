"""om package

Expose helpers from the `om` module.
"""
from .om import cum, teasing, penetration, hedonism, cuddling, fwb

__all__ = ["cum", "teasing", "penetration", "hedonism", "cuddling", "fwb"]
